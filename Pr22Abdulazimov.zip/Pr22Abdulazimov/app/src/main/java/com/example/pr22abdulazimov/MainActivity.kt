package com.example.pr22abdulazimov

import android.graphics.Color
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.support.design.widget.Snackbar
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView
import com.android.volley.Request
import com.android.volley.toolbox.StringRequest
import com.android.volley.toolbox.Volley
import com.google.gson.JsonObject
import org.json.JSONObject

class MainActivity : AppCompatActivity() {
    private lateinit var cityName: EditText;
    private lateinit var city1: TextView;
    private lateinit var temp1: TextView;
    private lateinit var davlenie: TextView;
    private lateinit var speed: TextView;

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        cityName = findViewById(R.id.cityName);
        city1 = findViewById(R.id.city);
        temp1 = findViewById(R.id.tempText);
        davlenie = findViewById(R.id.davlenie);
        speed = findViewById(R.id.speed);
    }

    fun getResult(city: String) {
        if(city.isNotEmpty() && city != null) {
            var key = "3dfd6d17e1726af829035cc9bd245628"
            var url = "https://api.openweathermap.org/data/2.5/weather?q=$city" +
                    "&appid=$key&lang=ru&units=metric";

            val queue = Volley.newRequestQueue(this)
            val stringRequest = StringRequest(
                Request.Method.GET,
                url,
                {
                        response ->
                    val obj = JSONObject(response)
                    val name = obj.getString("name")
                    val main = obj.getJSONObject("main")
                    city1.text = "Название: $name";
                    temp1.text = "Температура: " + main.getString("temp").toString()
                    davlenie.text = "Давление: " + main.getString("pressure").toString()

                    val wind = obj.getJSONObject("wind")
                    speed.text = "Скорость ветра: " + wind.getString("speed").toString()

                    cityName.text = null;
                },
                {
                    var sn =  Snackbar.make(findViewById<View>(android.R.id.content),
                        "Введите название города правильно!", Snackbar.LENGTH_LONG)

                    sn.setActionTextColor(Color.RED);
                    sn.show();
                }
            )

            queue.add(stringRequest)
        }
        else {
            var sn =  Snackbar.make(findViewById<View>(android.R.id.content),
            "Введите название города!", Snackbar.LENGTH_LONG)

            sn.setActionTextColor(Color.RED);
            sn.show();
        }
    }

    fun searchCity(view: View) {
        getResult(cityName.text.toString())
    }
}

/*
fun getResult(city: String) {
        if(cityName.text.toString().isNotEmpty() && cityName.text.toString() != null) {
            val key = "3dfd6d17e1726af829035cc9bd245628"
            val url = "https://api.openweathermap.org/data/2.5/weather?q=${cityName.text}" +
                    "&appid=$key&lang=ru&units=metric";

            val queue = Volley.newRequestQueue(this)
            val stringRequest = StringRequest(
                Request.Method.GET, url, {
                        response ->
                    val obj = JsonObject(response)
                    /*val name = response.getString("name");
                val main = response.getString("main");
                val temp1 = response.getString("temp");
                val pressure = response.getString("pressure");
                val wind = response.getJSONObject("wind").getDouble("speed").toString();*/

                    /*val df = DecimalFormat("#")

                    city1.text = name;
                    temp.text = temp1;
                    davlenie.text = pressure;
                    speed.text = "Скорость:" + wind;*/
                },
                { error ->

                }
            )

        }
    }
*/